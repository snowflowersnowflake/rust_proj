use std::io;
use rand::Rng;

fn main() {
    println!("Guess the number!");
    let secret_number = rand::thread_rng().gen_range(1..101); //rand::thread_rng 函数提供随机数生成器 gen_range方法在1-101生成一个随机数。
    println!("The secret number is : {}", secret_number);
    println!("Please input your guess.");
    let mut guess = String::new();
    io::stdin().read_line(&mut guess).expect("Failed to read line");
    println!("you guess:{}", guess);

}


// 2 | use rand::Rng;
// |     ^^^^ use of undeclared crate or module `rand`

// https://crates.io/crates/rand
// Add this to your Cargo.toml:
// [dependencies]
// rand = "0.8.0"