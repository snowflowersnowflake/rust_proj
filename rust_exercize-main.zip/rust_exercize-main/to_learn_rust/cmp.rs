use std::io;
use std::cmp::Ordering;
use rand::Rng;

fn main() {
    loop{ //loop创建循环
        println!("Guess the number!");
        let secret_number = rand::thread_rng().gen_range(1..101);
        println!("The secret number is: {}", secret_number);
        println!("Please input your guess.");
        let mut guess = String::new();

        io::stdin()
            .read_line(&mut guess)
            .expect("Failed to read line");

        let guess: u32 = match guess.trim().parse() { // 类型转换 parse用于解析数字 trim用于去\字符
            Ok(num) => num, //处理无效输入
            Err(_) => continue,
        };

        println!("You guessed: {}", guess);

        match guess.cmp(&secret_number) { // ordering 枚举Less、Greater 和 Equal 三个结果，通过match匹配arms的pattern
            Ordering::Less => println!("too small"),
            Ordering::Equal => println!("equ"),
            Ordering::Greater => println!("too big"),
        }
    }
}

// C:/Users/y00/.cargo/bin/cargo.exe build --color=always --message-format=json-diagnostic-rendered-ansi --package rust_proj --bin rust_proj
// error: process didn't exit successfully: `C:\Users\y00\.cargo\bin\rustc.exe -vV` (exit code: 1)
// --- stderr
// error: the 'rustc.exe' binary, normally provided by the 'rustc' component, is not applicable to the 'stable-x86_64-pc-windows-gnu' toolchain
// Process finished with exit code 101


// Theoretically this could fix lack of the rustc component:
// rustup component add rustc
// rustup default stable
