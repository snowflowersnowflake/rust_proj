use std::io;

fn main() {
    println!("Guess the number!");
    println!("Please input your guess.");
    let mut guess = String::new(); // mutable 使变量可变 rust中let默认变量不可变 =右边是绑定的值 String::new()会返回 String 的新实例
    io::stdin().read_line(&mut guess)
        .expect("Failed to read line"); // 标准读入 read返回一个enums Result包含成员ok和err expect获取ok的值 如果是err会使得程序崩溃
    println!("You guessed: {}", guess);
}
